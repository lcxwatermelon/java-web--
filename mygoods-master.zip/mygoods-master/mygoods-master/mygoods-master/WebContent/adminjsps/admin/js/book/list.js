$(function() {
	$(".inner").hover(function() {
		$(this).css("border", "3px solid #FFCFB1");
	}, function() {
		$(this).css("border", "3px solid #ffffff");
	});
});